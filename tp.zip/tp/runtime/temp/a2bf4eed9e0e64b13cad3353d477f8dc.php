<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\se\se.html";i:1530228825;}*/ ?>

<?php foreach($rs as $v): ?>
&nbsp;
<?php echo $v['cid']; ?>
<br />
<?php endforeach; ?> 
