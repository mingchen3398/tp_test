<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Paginator;
session_start();
class Clas extends Controller
{
	public function clas()
	{
		$rs=Db::table('class')->paginate(6);
		$rs1=Db::table('user')->where('user',$_SESSION['user'])->find();
		$i=1;
		return view('',['rs'=>$rs,'rs1'=>$rs1,'i'=>$i]);
	}
	public function modCla()
	{
		if(input('?post.sub'))
		{
			$hid=input('hid');
			$cname=input('cname');
			$rs = Db::name('class')->where('id',$hid)->update(['cname'=>$cname]);
			if($rs)
				$this->success('修改成功','index/clas/clas');
			else
				$this->error('修改失败');
		}
		else
		{
			$id=input('id');
			$rs=Db::name('class')->where('id',$id)->find();
			return view('',['rs'=>$rs]);
		}
	}
	public function addCla()
	{
		if(input('?post.sub'))
		{
			$cname=input('cname');
			$rs = Db::name('class')->insert(['id'=>null,'cname'=>$cname]);
			if($rs)
				$this->success('添加成功','index/clas/clas');
			else
				$this->error('添加失败');
		}
		else
		{
			return view();
		}
	}
	public function delCla()
	{
		$id=input('id');
		$rs = Db::table('class')->delete($id);
		if($rs)
			$this->success('删除成功','index/clas/clas');
		else
			$this->error('删除失败');
	}
}