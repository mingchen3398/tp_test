<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\user\user.html";i:1530174691;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="../../../css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../../../js/jquery.js"></script>
</head>
<body>
	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="<?php echo url('index/stu/stu'); ?>">首页</a></li>
    <li><a href="<?php echo url('index/user/user'); ?>">所有用户</a></li>
    </ul>
    </div>
    <div class="rightinfo">
    <div class="tools">
    	<ul class="toolbar">
		<a href="<?php echo url('index/user/addUser'); ?>">
        <li class="click"><span><img src="../../../images/t01.png" /></span>添加</li>
		</a>
        </ul>
    </div>
    <table class="tablelist">
    	<thead>
    	<tr>
        <th  width="8%">编号<i class="sort"><img src="../../../images/px.gif" /></i></th>
        <th width="15%">用户名</th>
        <th width="5%">密码</th>
        <th  width="10%">注册时间</th>
        <th  width="15%">上次登录</th>
		<th  width="20%">登录次数</th>
		<?php if($rs1['power']==0): ?>
        <th>操作</th>
		<?php endif; ?>
        </tr>
        </thead>
	  	<?php foreach($rs as $user): ?>
        <tr>
        <td><?php echo $i++; ?></td>
        <td><?php echo $user['user']; ?></td>
        <td><?php echo $user['pwd']; ?></td>
        <td><?php echo $user['regtime']; ?></td>
		<td><?php echo $user['logintime']; ?></td>
        <td><?php echo $user['times']; ?></td>
		<?php if($rs1['power']==0): ?>
        <td><a class="button border-red" href="<?php echo url('index/user/delUser'); ?>?id=<?php echo $user['id']; ?>">删除</a>|<a class="button border-main" href="<?php echo url('index/user/modUser'); ?>?id=<?php echo $user['id']; ?>">编辑</a></td>
        </tr>   
		<?php endif; endforeach; ?>
        <span style="position:absolute; top:330px; right:120px"><?php echo $rs->render(); ?><span>
    </table>
<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>
