<?php
// [ 应用入口文件 ]

//绑定当前访问到index模块的index模块
define('BING_MODULE','index');
// 定义应用目录
define('APP_PATH', __DIR__ . '/../app/');
// 加载框架引导文件
require __DIR__ . '/../thinkphp/start.php';
