<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\index\user_me.html";i:1530236138;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="../../../css/style.css" rel="stylesheet" type="text/css" />
<style>
.nowtime{ position:absolute;left:1050px; top:80px; color:red}
.month{ color:blue}
</style>
</head>

<body>

	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="../../index/stu/stu">首页</a></li>
    <li><a href="../../index/index/userMe?id=<?php echo $rs['id']; ?>">用户详情</a></li>
    </ul>
    </div>
    
    <div class="formbody">
    
    <div class="formtitle"><span>基本信息</span></div>
    <form action="" method="post" enctype="multipart/form-data">
    <?php if($rs['power']==0): ?>
	<ul class="forminfo">
		<li>
				<label>ID</label>
				<?php echo $rs['id']; ?>
		</li>
		<li>
				<label>用户名:</label>
				<input type="text" name="user" value="<?php echo $rs['user']; ?>" class="dfinput" >
		</li>
		<li>
			<label>密码:</label>
			<input type="password"  value="******" disabled class="dfinput" >
		</li>
		<li>
			<label>注册时间:</label>
			<input type="text" name="regtime"  value="<?php echo $rs['regtime']; ?>" class="dfinput">
		</li>
		<li>
			<label>上次登录:</label>
			<input type="text" name="logintime" value="<?php echo $rs['logintime']; ?>"  class="dfinput">
		</li>
		<li>
			<label>登录次数</label>
			<input type="text" name="times" value="<?php echo $rs['times']; ?>" class="dfinput">
		</li>
		<li>
		<li>
			<label><input type="hidden" name="hid" value="<?php echo $rs['id']; ?>"></label>
			<input name="sub" type="submit" class="btn" value="提交"/>
		</li>
    </ul>
	<?php endif; if($rs['power']!=0): ?>
	<ul class="forminfo">
		<li>
				<label>ID</label>
				<?php echo $rs['id']; ?>
		</li>
		<li>
				<label>用户名:</label>
				<input type="text" name="user" value="<?php echo $rs['user']; ?>" disabled class="dfinput" >
		</li>
		<li>
			<label>密码:</label>
			<input type="password"  value="sha1(<?php echo $rs['pwd']; ?>)" disabled class="dfinput" >
		</li>
		<li>
			<label>注册时间:</label>
			<input type="text" name="regtime"  value="<?php echo $rs['regtime']; ?>" class="dfinput" disabled>
		</li>
		<li>
			<label>上次登录:</label>
			<input type="text" name="logintime" value="<?php echo $rs['logintime']; ?>" disabled  class="dfinput">
		</li>
		<li>
			<label>登录次数</label>
			<input type="text" name="times" value="<?php echo $rs['times']; ?>" disabled class="dfinput">
		</li>
		<li>
    </ul>
	<span style="color:red; font-size:20px">若更改信息，请捐赠并留下信息</span>
	<img style="position:relative; left:70%; top:20%" src="../../../images/alipay.jpg" width="108"/>
	<?php endif; ?>
	<!--js时间-->
<div class="nowtime">
 <td>系统时间:</td>
 <script language=Javascript> 
  function time(){
    //获得显示时间的div
    t_div = document.getElementById('showtime');
   var now=new Date()
    //替换div内容 
   t_div.innerHTML = " "+now.getFullYear()
    +"年"+(now.getMonth()+1)+"月"+now.getDate()+"日<i class=\"month\">"+now.getHours()+"时"+now.getMinutes()
    +"分"+now.getSeconds()+"秒</i>";
    //等待一秒钟后调用time方法，由于settimeout在time方法内，所以可以无限调用
   setTimeout(time,1000);
  }
</script>
</head>
<body  onload="time()">
<div id="showtime">
</div>
</div>
	</form>
    </div>


<div style="display:none"><script src='1' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>
