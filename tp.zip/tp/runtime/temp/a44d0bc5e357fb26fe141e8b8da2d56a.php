<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\stu\add.html";i:1530063552;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="../../../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="stu.php">首页</a></li>
    <li><a href="<?php echo url("","",true,false);?>">学生添加</a></li>
    </ul>
    </div>
    
    <div class="formbody">
    
    <div class="formtitle"><span>基本信息</span></div>
    <form action="" method="post" enctype="multipart/form-data">
    <ul class="forminfo">
    <li><label>姓名：</label><input type="text" name="name" class="dfinput" required></li>
    <li><label>性别:</label><input type="radio" name="sex" value="男" checked="checked">男
		<input type="radio" name="sex" value="女">女</li>
    <li><label>生日</label><input type="date" name="birthday"  class="dfinput" required></li>
    <li><label>电话</label><input type="text" name="tel" class="dfinput" required></li>
    <li><label>爱好</label><?php foreach($hobby as $value): ?>
		<input type="checkbox" name="hobby[]" value="<?php echo $value; ?>"><?php echo $value; endforeach; ?></li>
	<li><label>班级</label><select class="dfinput" id="cid"  name="cid">
		<?php foreach($rs as $cla): ?>
		<option  name="class" value=<?php echo $cla['id']; ?>><?php echo $cla['cname']; ?></option>
		<?php endforeach; ?>
		</select></li>

	<li><label>&nbsp;</label><input name="sub" type="submit" class="btn" value="提交"/></li>
    </ul>
    
    
    </div>


<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>
