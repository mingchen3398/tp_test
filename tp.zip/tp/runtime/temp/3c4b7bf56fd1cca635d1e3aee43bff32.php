<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\clas\mod_cla.html";i:1530164897;}*/ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>无标题文档</title>
<link href="../../../css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="stu.php">首页</a></li>
    <li><a href="addStu.php">班级修改</a></li>
    </ul>
    </div>
    <div class="formbody">
    <div class="formtitle"><span>基本信息</span></div>
    <form action="" method="post" enctype="multipart/form-data">
    <ul class="forminfo">
    <li><label>班级名称</label><input type="text" name="cname" class="dfinput" value="<?php echo $rs['cname']; ?>" ></li>
	<li><label><input type="hidden" name="hid" value="<?php echo $rs['id']; ?>"></label>
			   <input name="sub" type="submit" class="btn" value="修改"/>
	</li>
    </ul>
    </div>
<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>
