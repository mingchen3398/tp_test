<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\index\stu.html";i:1530083241;}*/ ?>
﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>学生信息表</title>
<link href="../../../css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="#">首页</a></li>
    <li><a href="#">数据表</a></li>
    <li><a href="#">基本内容</a></li>
    </ul>
    </div>
    <div class="rightinfo">
    <div class="tools">
    	<ul class="toolbar">
		<a href="<?php echo url('index/Add/add'); ?>">
        <li class="click"><span><img src="../../../images/t01.png" /></span>添加</li>
		</a>
        </ul>
    <table class="tablelist">
    	<thead>
    	<tr>
        <th  width="8%">编号<i class="sort"><img src="../../../images/px.gif" /></i></th>
        <th width="15%">姓名</th>
        <th width="5%">性别</th>
        <th  width="15%">生日</th>
		<th  width="10%">电话</th>
		<th  width="20%">爱好</th>
        <th width="10%">班级</th>
        <th>操作</th>
        </tr>
        </thead>
		
	  	<?php foreach($rs as $stu): ?>
        <tr>
        <td><?php echo $i++; ?></td>
        <td><?php echo $stu['sname']; ?></td>
        <td><?php echo $stu['sex']; ?></td>
        <td><?php echo $stu['birthday']; ?></td>
		<td><?php echo $stu['tel']; ?></td>
		<td><?php echo $stu['hobby']; ?></td>
        <td><?php echo $stu['cname']; ?></td>
        <td><a class="button border-red" href="<?php echo url('index/del/del'); ?>?id=<?php echo $stu['id']; ?>">删除</a>|<a class="button border-main" href="<?php echo url('index/Modstu/modstu'); ?>?id=<?php echo $stu['id']; ?>">编辑</a></td><!-- 接收不到id <?php echo url('index/Modstu/modstu',['id'=>$stu['id']]); ?> -->
        </tr>   
		<?php endforeach; ?>
		
    </table>
<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>
