<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
session_start();
class Login extends Controller
{
	public function login()
	{
		if(input('?post.sub'))
		{
			$user=input('user');
			$pwd=input('pwd');
			$rs=Db::table('user')
				->where('user',$user)
				->where('pwd',$pwd)
				->find();
			$times=$rs['times'];
			$id=$rs['id'];
			if(count($rs)>0)
			{
				$_SESSION['user']=$rs['user'];
				$_SESSION['power']=$rs['power'];
				$_SESSION['id']=$rs['id'];
				$times=$times+1;
				$logintime=date('Y-m-d H:i:s',time());
				Db::table('user')->where('id',$id)
		   		->update(['logintime' => $logintime,'times' => $times]);
				$this->success('登陆成功','index/index/index');
			}
			else
			{
				return view('');
			}
		}
		else
		{
			return view('');
		}
	}
}






