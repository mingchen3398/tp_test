<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\user\add_user.html";i:1530166780;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="../../../css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="stu.php">首页</a></li>
    <li><a href="<?php echo url('index/user/addUser'); ?>">用户添加</a></li>
    </ul>
    </div>
    
    <div class="formbody">
    
    <div class="formtitle"><span>基本信息</span></div>
    <form action="" method="post" enctype="multipart/form-data">
    <ul class="forminfo">
    <li><label>用户名</label><input type="text" name="user" class="dfinput" ></li>
	<li><label>用户密码</label><input type="text" name="pwd" class="dfinput" ></li>
	<li><label>&nbsp;</label><input name="sub" type="submit" class="btn" value="添加"/></li>
    </ul>
    
    
    </div>


<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>
