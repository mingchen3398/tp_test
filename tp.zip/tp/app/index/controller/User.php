<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Paginator;
session_start();
class User extends Controller
{
	public function user()
	{
		$rs=Db::table('user')->paginate(6);
		$rs1=Db::table('user')->where('user',$_SESSION['user'])->find();
		$i=1;
		return view('',['rs'=>$rs,'rs1'=>$rs1,'i'=>$i]);
	}
	public function addUser()
	{
		if(input("?post.sub"))
		{
			$user=input('user');
			$pwd=input('pwd');
			$regtime=date('Y-m-d H:i:s',time());
			$rs=Db::table('user')->insert(['id'=>"null",'user'=>$user,'pwd'=>$pwd,'power'=>1,'powername'=>'用户组','regtime'=>$regtime,'times'=>0]);
			if($rs)
				$this->success('添加成功','index/user/user');
			else
				$this-error('添加失败');
		}
		else
		{
			return view();
		}
	}
	public function modUser()
	{
		if(input('post.sub'))
		{
			$hid=input('hid');
			$user=input('user');
			$pwd=input('pwd');
			$power=input('power');
			$times=input('times');
			$regtime=input('regtime');
			$logintime=input('logintime');
			$rs = Db::table('user')
		    ->where('id',$hid)
		    ->update(['user' => "$user",'pwd' => "$pwd",'power' => "$power",'times' => "$times",'regtime' => "$regtime",'logintime' => "$logintime"]);
			if($rs)
				$this->success('修改成功','index/user/user');
			else
				$this->error('修改失败');
		}
		else
		{
			$id=input('id');
			$rs =Db::table('user')->where('id',$id)->find();
			return view('',['rs'=>$rs]);
		}
	}
	public function delUser()
	{
		$id=input('id');
		$rs = Db::table('user')->delete($id);
		if($rs)
			$this->success('删除成功','index/user/user');
		else
			$this->error('删除失败');
	}

}