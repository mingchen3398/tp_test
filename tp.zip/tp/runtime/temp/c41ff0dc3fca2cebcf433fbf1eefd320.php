<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\student\list.html";i:1529895341;}*/ ?>
<?php foreach($arr as $a): ?>
<?php echo $a; ?> &nbsp;
<?php endforeach; ?>