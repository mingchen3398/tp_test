<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Paginator;
class Se extends Controller
{
	//查询     	//http://localhost/tp/public/index.php/index/se/se
	/*public  function se()
	{
	   $rs =Db::table('stu')
		->alias('s')
		->join('class c','s.cid = c.id')
		->order('sex')
		//->fetchSql(true)
		->select();
		return view('',['rs'=>$rs]);
	}(1)
	*/
/*
	public  function se()
	{
	   $rs =Db::table('stu')
		->alias('s')
		->field('sname,sex,birthday')
		->join('class c','s.cid = c.id')
		->order('sex')
		//->fetchSql(true)
		->select();

		$i=1;
		return view('',['rs'=>$rs,'i'=>$i]);
	}(2)
	*/

	public  function se()
	{
	   $rs =Db::table('stu')
		->alias('s')
		->join('class c','s.cid = c.id')
		->order('cid asc,sname desc')
		->select();
		return view('',['rs'=>$rs]);
	}
}