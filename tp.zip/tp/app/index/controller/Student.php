<?php
namespace app\index\controller;
use think\Controller;
class Student extends Controller
{
    public function list()
    {
        $arr=array('果冻','天文','辉文','胜胜','玉龙','王玉','小葱','露露','孔明','丛杰');
        $this->assign('arr',$arr);
        return view('');
    }
}
//http://localhost/tp/public/index.php/index/Student/list