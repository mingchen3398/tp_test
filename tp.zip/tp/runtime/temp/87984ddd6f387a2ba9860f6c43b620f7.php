<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\clas\clas.html";i:1530174644;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="../../../css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../../../js/jquery.js"></script>
</head>
<body>
	<div class="place">
    <span>位置：</span>
    <ul class="placeul">
    <li><a href="<?php echo url('index/stu/stu'); ?>">首页</a></li>
    <li><a href="<?php echo url('index/clas/addcla'); ?>">所有班级</a></li>
    </ul>
    </div>
    <div class="rightinfo">
    <div class="tools">
    	<ul class="toolbar">
		<a href="<?php echo url('index/clas/addcla'); ?>">
        <li class="click"><span><img src="../../../images/t01.png" /></span>添加</li>
		</a>
        </ul>
    </div>
    <table class="tablelist">
    	<thead>
    	<tr>
        <th  width="8%">编号<i class="sort"><img src="../../../images/px.gif" /></i></th>
        <th width="15%">班级名称</th>
		<?php if($rs1['power']==0): ?>
        <th>操作</th>
		<?php endif; ?>
        </tr>
        </thead>
	  	<?php foreach($rs as $clas): ?>
        <tr>
        <td><?php echo $i++; ?></td>
        <td><?php echo $clas['cname']; ?></td>
		<?php if($rs1['power']==0): ?>
        <td><a class="button border-red" href="../../index/clas/delCla?id=<?php echo $clas['id']; ?>">删除</a>|<a class="button border-main" href="../../index/clas/modCla?id=<?php echo $clas['id']; ?>">编辑</a></td>
        </tr>   
		<?php endif; endforeach; ?>
        <span style="position:absolute; top:330px; right:120px"><?php echo $rs->render(); ?><span>
    </table>
    
    <div class="tip">
        <div class="tipbtn">
        <input name="" type="button"  class="sure" value="确定" />&nbsp;
        <input name="" type="button"  class="cancel" value="取消" />
        </div>
    </div>
    </div>
    <script type="text/javascript">
	$('.tablelist tbody tr:odd').addClass('odd');
	</script>
<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>
