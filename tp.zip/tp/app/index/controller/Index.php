<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
session_start();
class Index extends Controller
{
	public function index()
	{	
		$rs=Db::table('user')->where('user',$_SESSION['user'])->find();;
		return view('',['rs'=>$rs]);
	}
	public function left()
	{
			$rs=Db::table('user')->where('user',$_SESSION['user'])->find();;
		    return view('',['rs'=>$rs]);
	}
	public function left1()
	{
		$rs=Db::table('user')->where('user',$_SESSION['user'])->find();;
		return view('',['rs'=>$rs]);
	}
	public function top()
	{
		$rs=Db::table('user')->where('user',$_SESSION['user'])->find();
		return view('',['rs'=>$rs]);
	}
	public function userMe()
	{
		if(input('?post.sub'))
		{
			$hid=input('hid');
			$user=input('user');
			$regtime=input('regtime');
			$logintime=input('logintime');
			$rs =Db::table('user')->where('id',$hid)
		   		->update(['user' => $user,'regtime' => $regtime,'logintime' => $logintime]);
			if($rs)
				$this->success('修改成功','index/index/userMe');
			else
				$this->error('修改失败');
		}
		else
		{
			$rs=Db::table('user')->where('user',$_SESSION['user'])->find();;
			return view('',['rs'=>$rs]);
		}
	}
	public function quit()
	{
    //销毁session
    session("user", NULL);
    //跳转页面
    $this->redirect('index/login/login');
	}
}