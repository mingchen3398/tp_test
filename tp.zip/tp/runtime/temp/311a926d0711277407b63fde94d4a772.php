<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\index\read.html";i:1529476894;}*/ ?>
<?php echo $name; ?>