<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Paginator;
class Stu extends Controller
{
	//查询     	//http://localhost/tp/public/index.php/index/stu/stu
	public  function stu()
	{
	   $rs =Db::view('stu','id,sname')
	    ->view('stu','cid,sname,tel,sex,birthday,hobby')
		->view('class','cname','class.id=stu.cid')
		->order('id desc')
		 ->paginate(6);
		$i=1;
		return view('',['rs'=>$rs,'i'=>$i]);
	}
	//添加    	//http://localhost/tp/public/index.php/index/stu/add
	public function add()
	{
		if(input("?post.sub"))
		{
			$sname=input('name');
			$sex=input('sex');
			$birthday=input('birthday');
			$tel=input('tel');
			$cid=input('cid');
			$hobby=input('hobby/a');
			$hobby=implode(',',$hobby);
			$rs = Db::name('stu')->insert(['sname'=>$sname,'sex'=>$sex,'birthday'=>$birthday,'tel'=>$tel,'cid'=>$cid,'hobby'=>$hobby]);
			if($rs)
				$this->success('添加成功','index/stu/stu');
			else
				$this->error('添加失败');
		}
		else
		{
			$hobby=array('足球','滑板','篮球');
			$rs =Db::table('class')
		    ->select();
			return view('add',['rs'=>$rs,'hobby'=>$hobby]);
		}
	}
	//删除     http://localhost/tp/public/index.php/index/stu/del?id=$id
	public function del()
	{
		$id=input('id');
		$rs = Db::table('stu')->delete($id);
		if($rs)
			$this->success('删除成功','index/stu/stu');
		else
			$this->error('删除失败');
	}
	//修改   http://localhost/tp/public/index.php/index/stu/update?id=$id
	public function modstu()
	{
		if(input("?post.sub"))
		{
			$hid=input('hid');
			$sname=input('sname');
			$sex=input('sex');
			$birthday=input('birthday');
			$hobby=input('hobby/a');
			$hobby=implode(',',$hobby);
			$tel=input('tel');
			$cid=input('cid');
			$rs = Db::table('stu')
		    ->where('id',$hid)
		    ->update(['sname' => "$sname",'sex' => "$sex",'birthday' => "$birthday",'hobby' => "$hobby",'tel' => "$tel",'cid' => "$cid"]);
			if($rs)
				$this->success('修改成功','index/stu/stu');
			else
				$this->error('修改失败');
		}
		else
		{	
			$id=input("get.id/d");
			$rs=Db::table('stu')
			->where('id',$id)
		    ->find();
			$hobby=explode(',',$rs['hobby']);

			$rs1 =Db::table('class')
		    ->select();
			$hobby=array('足球','滑板','篮球');
			return view('modStu',["rs"=>$rs,'rs1'=>$rs1,'hobby'=>$hobby]);
		}
	}

}