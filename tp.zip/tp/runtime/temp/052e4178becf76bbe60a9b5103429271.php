<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:72:"E:\phpStudy\PHPTutorial\WWW\tp\public/../app/index\view\login\login.html";i:1530231572;s:61:"E:\phpStudy\PHPTutorial\WWW\tp\app\index\view\comm\style.html";i:1529916935;}*/ ?>
<!DOCTYPE html>
<head>
<title>登录</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="/tp/public/static/css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="/tp/public/static/css/style.css" rel='stylesheet' type='text/css' />
<link href="/tp/public/static/css/style-responsive.css" rel="stylesheet"/>
<!-- font-awesome icons -->
<link rel="stylesheet" href="/tp/public/static/css/font.css" type="text/css"/>
<link href="/tp/public/static/css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="/tp/public/static/css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="/tp/public/static/css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="/tp/public/static/js/jquery2.0.3.min.js"></script>
<script src="/tp/public/static/js/raphael-min.js"></script>
<script src="/tp/public/static/js/morris.js"></script>
<link href="./css/drag.css" rel="stylesheet" type="text/css">
<script src="./js/jquery-1.7.2.min.js" type="text/javascript"></script>
<script src="./js/drag.js" type="text/javascript"></script> 
</head>
<body>
<div class="log-w3">
<div class="w3layouts-main">
    <h2>交院管理员登录系统</h2>
        <form action="#" method='post' enctype='multipart/form-data'>
            <input type="text" class="ggg" name="user" placeholder="请输入用户名" required />
            <input type="password" class="ggg" name="pwd" placeholder="请输入密码" required />
            <center><br><br><br><div id="drag"></div></center>
            <input type="submit" value="登录" name="sub" onclick="return abc()" />
        </form>
</div> 
<script type="text/javascript">
$('#drag').drag();
function abc(){
    var a=document.getElementById('info').innerHTML;
    if(a=='拖动滑块验证')
    {
    alert('请输入验证码！');
        return false;
    }else
        return true;
}
</script>
<script src="./js/bootstrap.js"></script>
<script src="./js/jquery.dcjqaccordion.2.7.js"></script>
<script src="./js/scripts.js"></script>
<script src="./js/jquery.slimscroll.js"></script>
<script src="./js/jquery.nicescroll.js"></script>
<script src="./js/jquery.scrollTo.js"></script>
</body>
</html>
